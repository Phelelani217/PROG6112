﻿namespace Raceway.Models.ViewModels
{
    public class ManageUserRolesViewModel
    {
        public string RoleId { get; set; } = string.Empty;
        public string RoleName { get; set; } = string.Empty;
        public bool isSelected { get; set; }
        public bool IsSelected { get; internal set; }
    }
}
