# RaceDay — POE Part 1: System Planning and Database

## Description
RaceDay is a system for managing running/race-day events. Organizers create events
and the categories (e.g. 10km, Half Marathon) within them; Athletes register,
browse events, enrol into a category for a specific event, and view their results
once the race has been captured by the Organizer.

This repository contains the Part 1 planning deliverables:
- `/docs/RaceDay_ERD.png` — Entity Relationship Diagram
- `/docs/API_Endpoint_Plan.md` — full API endpoint specification
- `/docs/RaceDay_Schema.sql` — SQL Server script to create and populate the schema

## Roles

| Role | Description |
|---|---|
| **Athlete** | Registers an account, browses events, enrols in a category for an event, and views their own results. |
| **Organizer** | Registers an account, creates and manages events and their categories, and captures results for athletes who enrolled. |

## Database
The schema has 6 entities: `Role`, `User`, `Event`, `Category`, `Enrolment`, `Result`.
See `/docs/RaceDay_ERD.png` for the full diagram with primary keys, foreign keys,
and cardinality, and `/docs/RaceDay_Schema.sql` for the matching SQL script.

## CI/CD
A GitHub Actions workflow (`.github/workflows/validate-structure.yml`) runs on every
push/PR to `main` and checks that the `/docs` folder exists and contains the required
planning files.

**Successful build screenshot:**
_(paste your green-check Actions screenshot here once you've pushed and the workflow has run)_

## Video walkthrough
_(add your unlisted YouTube link here — walk through the planning documents, your ERD
decisions, and the endpoint plan)_
