# RaceDay System — API Endpoint Plan

Roles: **Athlete** and **Organizer** (see ERD `Role` entity).

| # | HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|---|
| 1 | POST | /api/auth/register | Register a new user as an Athlete or Organizer | Public | `{ fullName, email, password, roleId }` | 201 Created, `{ userId, token }` |
| 2 | POST | /api/auth/login | Authenticate a user and issue a token | Public | `{ email, password }` | 200 OK, `{ token, userId, role }` |
| 3 | GET | /api/users/{id} | Retrieve a user's profile | Athlete/Organizer (self) | — | 200 OK, `{ userId, fullName, email, role }` |
| 4 | PUT | /api/users/{id} | Update the authenticated user's profile | Athlete/Organizer (self) | `{ fullName, email }` | 200 OK, updated user object |
| 5 | GET | /api/events | List all events | Public | — | 200 OK, array of events |
| 6 | GET | /api/events/{id} | Get details for a single event | Public | — | 200 OK, event object |
| 7 | POST | /api/events | Create a new event | Organizer | `{ eventName, eventDate, location }` | 201 Created, event object |
| 8 | PUT | /api/events/{id} | Update an event owned by the caller | Organizer (owner) | `{ eventName, eventDate, location }` | 200 OK, updated event |
| 9 | DELETE | /api/events/{id} | Delete an event owned by the caller | Organizer (owner) | — | 204 No Content |
| 10 | GET | /api/events/{eventId}/categories | List categories for an event | Public | — | 200 OK, array of categories |
| 11 | POST | /api/events/{eventId}/categories | Add a category to an event | Organizer (owner) | `{ categoryName, distance }` | 201 Created, category object |
| 12 | PUT | /api/categories/{id} | Update a category | Organizer (owner) | `{ categoryName, distance }` | 200 OK, updated category |
| 13 | DELETE | /api/categories/{id} | Delete a category | Organizer (owner) | — | 204 No Content |
| 14 | POST | /api/enrolments | Enrol the caller into a category | Athlete | `{ categoryId }` | 201 Created, enrolment object |
| 15 | GET | /api/enrolments/my | List the caller's own enrolments | Athlete | — | 200 OK, array of enrolments |
| 16 | GET | /api/categories/{id}/enrolments | List all enrolments for a category | Organizer (owner) | — | 200 OK, array of enrolments |
| 17 | DELETE | /api/enrolments/{id} | Cancel the caller's own enrolment | Athlete (owner) | — | 204 No Content |
| 18 | POST | /api/results | Capture a result for an enrolment | Organizer (owner) | `{ enrolmentId, finishTime, position }` | 201 Created, result object |
| 19 | PUT | /api/results/{id} | Update a captured result | Organizer (owner) | `{ finishTime, position }` | 200 OK, updated result |
| 20 | GET | /api/results/event/{eventId} | List all results for an event | Public | — | 200 OK, array of results |
| 21 | GET | /api/results/my | List the caller's own results | Athlete | — | 200 OK, array of results |

## Notes
- "Owner" checks mean the API must confirm `OrganizerID` (for events/categories/results) or `UserID` (for enrolments) matches the authenticated user's ID before allowing the write.
- Every endpoint maps directly to an entity in the ERD, so Part 2 code should not introduce new tables without updating this plan and the ERD first.
