namespace RaceDay.Mvc.Helpers;

public static class Fmt
{
    public static string Ordinal(int n)
    {
        if (n % 100 is >= 11 and <= 13) return $"{n}th";
        return (n % 10) switch { 1 => $"{n}st", 2 => $"{n}nd", 3 => $"{n}rd", _ => $"{n}th" };
    }
    public static string BadgeClass(string? status) => (status ?? "").ToLower() switch
    {
        "confirmed" => "status-confirmed",
        "pending" => "status-pending",
        "cancelled" or "rejected" => "status-cancelled",
        _ => "status-other"
    };
}
