using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;

public class LoginRequest
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
}

public class RegisterRequest
{
    [Required, Display(Name = "Full name")] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, MinLength(6), DataType(DataType.Password)] public string Password { get; set; } = "";
    [Required] public string Role { get; set; } = "Participant";
}

public class AuthResponse
{
    public string Token { get; set; } = "";
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
}

public class EventDto
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTime Date { get; set; }
    public string Location { get; set; } = "";
    public double DistanceKm { get; set; }
    public string EventType { get; set; } = "";
    public string? BannerUrl { get; set; }
    public int EnrolmentCount { get; set; }
}

public class EventFormVm
{
    public int Id { get; set; }
    [Required] public string Name { get; set; } = "";
    [Required] public string Description { get; set; } = "";
    [Required, DataType(DataType.DateTime)] public DateTime Date { get; set; } = DateTime.Today.AddDays(30);
    [Required] public string Location { get; set; } = "";
    [Required, Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km"), Display(Name = "Distance (km)")]
    public double DistanceKm { get; set; }
    [Required, Display(Name = "Event type")] public string EventType { get; set; } = "Road Run";
    public string? BannerUrl { get; set; }
    [Display(Name = "Banner image")] public IFormFile? Banner { get; set; }
}

public class CategoryDto
{
    public int Id { get; set; }
    public int EventId { get; set; }
    public string Name { get; set; } = "";
    public string Type { get; set; } = "Age";
}

public class EnrolmentDto
{
    public int Id { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = "";
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = "";
    public string Status { get; set; } = "Pending";
}

public class ResultEntryDto
{
    public int EnrolmentId { get; set; }
    public string FinishTime { get; set; } = "";
    public int Position { get; set; }
}

public class ResultDto
{
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = "";
    public string FinishTime { get; set; } = "";
    public int Position { get; set; }
    public int TotalFinishers { get; set; }
}

public class ProfileDto
{
    [Required, Display(Name = "Full name")] public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    [Phone] public string? Phone { get; set; }
    public string? ProfilePictureUrl { get; set; }
}
