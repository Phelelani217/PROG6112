using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Mvc.Filters;

/// <summary>Blocks unauthenticated users; optionally restricts to a role.</summary>
public class SessionAuthAttribute : ActionFilterAttribute
{
    private readonly string? _role;
    public SessionAuthAttribute(string? role = null) => _role = role;

    public override void OnActionExecuting(ActionExecutingContext ctx)
    {
        var s = ctx.HttpContext.Session;
        if (string.IsNullOrEmpty(s.GetString("token")))
        {
            if (ctx.Controller is Controller c) c.TempData["Error"] = "Please log in to continue.";
            ctx.Result = new RedirectToActionResult("Login", "Account", null);
        }
        else if (_role != null && !string.Equals(s.GetString("role"), _role, StringComparison.OrdinalIgnoreCase))
        {
            ctx.Result = new RedirectToActionResult("Denied", "Account", null);
        }
    }
}
