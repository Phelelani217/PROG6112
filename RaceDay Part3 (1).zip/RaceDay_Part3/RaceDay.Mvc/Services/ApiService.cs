using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Mvc.Services;

/// <summary>Every route the MVC app calls on the Part 2 API. Edit here to match your API.</summary>
public static class Routes
{
    public const string Login = "api/auth/login";
    public const string Register = "api/auth/register";
    public const string Events = "api/events";
    public const string MyEvents = "api/events/mine";
    public const string Enrol = "api/enrolments";
    public const string MyEnrolments = "api/enrolments/mine";
    public const string MyResults = "api/results/mine";
    public const string Profile = "api/profile";
    public const string ProfilePicture = "api/profile/picture";
    public static string Event(int id) => $"api/events/{id}";
    public static string Banner(int id) => $"api/events/{id}/banner";
    public static string Categories(int eventId) => $"api/events/{eventId}/categories";
    public static string Category(int id) => $"api/categories/{id}";
    public static string EventEnrolments(int eventId) => $"api/events/{eventId}/enrolments";
    public static string Results(int eventId) => $"api/events/{eventId}/results";
}

public class ApiResult<T>
{
    public bool Ok { get; set; }
    public T? Data { get; set; }
    public string Error { get; set; } = "";
}

/// <summary>The only place the MVC app talks to the outside world: the Part 2 API.</summary>
public class ApiService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _ctx;
    private static readonly JsonSerializerOptions J = new(JsonSerializerDefaults.Web);

    public ApiService(HttpClient http, IHttpContextAccessor ctx) { _http = http; _ctx = ctx; }

    public Task<ApiResult<T>> Get<T>(string url) => Send<T>(HttpMethod.Get, url);
    public Task<ApiResult<T>> Post<T>(string url, object body) => Send<T>(HttpMethod.Post, url, JsonContent.Create(body, options: J));
    public Task<ApiResult<T>> Put<T>(string url, object body) => Send<T>(HttpMethod.Put, url, JsonContent.Create(body, options: J));
    public Task<ApiResult<T>> Delete<T>(string url) => Send<T>(HttpMethod.Delete, url);

    public async Task<ApiResult<T>> Upload<T>(string url, IFormFile file, string field = "file")
    {
        var form = new MultipartFormDataContent();
        var stream = new StreamContent(file.OpenReadStream());
        stream.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        form.Add(stream, field, file.FileName);
        return await Send<T>(HttpMethod.Post, url, form);
    }

    private async Task<ApiResult<T>> Send<T>(HttpMethod method, string url, HttpContent? content = null)
    {
        try
        {
            var req = new HttpRequestMessage(method, url) { Content = content };
            var token = _ctx.HttpContext?.Session.GetString("token");
            if (!string.IsNullOrEmpty(token))
                req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var res = await _http.SendAsync(req);
            var body = await res.Content.ReadAsStringAsync();

            if (!res.IsSuccessStatusCode)
                return new ApiResult<T> { Ok = false, Error = Friendly(res.StatusCode, body) };

            T? data = default;
            if (typeof(T) != typeof(object) && !string.IsNullOrWhiteSpace(body))
                data = JsonSerializer.Deserialize<T>(body, J);
            return new ApiResult<T> { Ok = true, Data = data };
        }
        catch (Exception)
        {
            return new ApiResult<T> { Ok = false, Error = "We couldn't reach the RaceDay service. Please try again shortly." };
        }
    }

    private static string Friendly(HttpStatusCode code, string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.ValueKind == JsonValueKind.Object && code != HttpStatusCode.InternalServerError)
                foreach (var key in new[] { "message", "error", "detail" })
                    if (doc.RootElement.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.String)
                        return v.GetString()!;
        }
        catch { /* body wasn't JSON */ }

        return code switch
        {
            HttpStatusCode.Unauthorized => "Your session has expired or your details are incorrect.",
            HttpStatusCode.Forbidden => "You don't have permission to do that.",
            HttpStatusCode.NotFound => "We couldn't find what you were looking for.",
            HttpStatusCode.BadRequest or HttpStatusCode.UnprocessableEntity => "Some of the information provided was invalid.",
            HttpStatusCode.Conflict => "That conflicts with existing data (for example, you may already be enrolled).",
            _ => "Something went wrong. Please try again."
        };
    }
}
