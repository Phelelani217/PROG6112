using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

public class AccountController : Controller
{
    private readonly ApiService _api;
    public AccountController(ApiService api) => _api = api;

    [HttpGet] public IActionResult Login() => View(new LoginRequest());

    [HttpPost]
    public async Task<IActionResult> Login(LoginRequest model)
    {
        if (!ModelState.IsValid) return View(model);
        var r = await _api.Post<AuthResponse>(Routes.Login, model);
        if (!r.Ok || r.Data == null || string.IsNullOrEmpty(r.Data.Token))
        {
            ModelState.AddModelError("", r.Ok ? "Login failed. Please try again." : r.Error);
            return View(model);
        }

        var role = r.Data.Role.Contains("organ", StringComparison.OrdinalIgnoreCase) ? "Organiser" : "Participant";
        HttpContext.Session.SetString("token", r.Data.Token);
        HttpContext.Session.SetString("role", role);
        HttpContext.Session.SetString("name", r.Data.FullName);
        HttpContext.Session.SetInt32("userId", r.Data.UserId);

        return role == "Organiser"
            ? RedirectToAction("Dashboard", "Organiser")
            : RedirectToAction("Index", "Home");
    }

    [HttpGet] public IActionResult Register() => View(new RegisterRequest());

    [HttpPost]
    public async Task<IActionResult> Register(RegisterRequest model)
    {
        if (!ModelState.IsValid) return View(model);
        if (model.Role != "Organiser" && model.Role != "Participant") model.Role = "Participant";
        var r = await _api.Post<object>(Routes.Register, model);
        if (!r.Ok)
        {
            ModelState.AddModelError("", r.Error);
            return View(model);
        }
        TempData["Success"] = "Account created. You can now log in.";
        return RedirectToAction(nameof(Login));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        TempData["Success"] = "You have been logged out.";
        return RedirectToAction(nameof(Login));
    }

    public IActionResult Denied() => View();
}
