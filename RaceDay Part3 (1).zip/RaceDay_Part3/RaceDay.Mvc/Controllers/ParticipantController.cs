using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Filters;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

[SessionAuth("Participant")]
public class ParticipantController : Controller
{
    private readonly ApiService _api;
    public ParticipantController(ApiService api) => _api = api;

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId <= 0)
        {
            TempData["Error"] = "Please choose a category before enrolling.";
            return RedirectToAction("Details", "Home", new { id = eventId });
        }
        var r = await _api.Post<object>(Routes.Enrol, new { eventId, categoryId });
        if (r.Ok) { TempData["Success"] = "You're enrolled! Check My Enrolments for your status."; return RedirectToAction(nameof(MyEnrolments)); }
        TempData["Error"] = r.Error;
        return RedirectToAction("Details", "Home", new { id = eventId });
    }

    public async Task<IActionResult> MyEnrolments()
    {
        var r = await _api.Get<List<EnrolmentDto>>(Routes.MyEnrolments);
        if (!r.Ok) TempData["Error"] = r.Error;
        return View((r.Data ?? new()).OrderBy(e => e.EventDate).ToList());
    }

    public async Task<IActionResult> MyResults()
    {
        var r = await _api.Get<List<ResultDto>>(Routes.MyResults);
        if (!r.Ok) TempData["Error"] = r.Error;
        return View((r.Data ?? new()).OrderByDescending(e => e.EventDate).ToList());
    }

    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var r = await _api.Get<ProfileDto>(Routes.Profile);
        if (!r.Ok) TempData["Error"] = r.Error;
        return View(r.Data ?? new ProfileDto());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(ProfileDto m)
    {
        if (!ModelState.IsValid) return View(m);
        var r = await _api.Put<object>(Routes.Profile, new { fullName = m.FullName.Trim(), phone = m.Phone });
        if (r.Ok) { HttpContext.Session.SetString("name", m.FullName.Trim()); TempData["Success"] = "Profile updated."; }
        else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Profile));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ProfilePicture(IFormFile? picture)
    {
        if (picture == null || picture.Length == 0) TempData["Error"] = "Please choose an image first.";
        else if (!new[] { "image/jpeg", "image/png", "image/webp" }.Contains(picture.ContentType)) TempData["Error"] = "Profile picture must be a JPG, PNG or WebP image.";
        else if (picture.Length > 5 * 1024 * 1024) TempData["Error"] = "Profile picture must be smaller than 5 MB.";
        else
        {
            var r = await _api.Upload<object>(Routes.ProfilePicture, picture);
            if (r.Ok) TempData["Success"] = "Profile picture updated."; else TempData["Error"] = r.Error;
        }
        return RedirectToAction(nameof(Profile));
    }
}
