using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Filters;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

[SessionAuth("Organiser")]
public class OrganiserController : Controller
{
    private readonly ApiService _api;
    public OrganiserController(ApiService api) => _api = api;

    private static readonly string[] AllowedImages = { "image/jpeg", "image/png", "image/webp" };
    private const long MaxImageBytes = 5 * 1024 * 1024;

    // ---------- Dashboard ----------
    public async Task<IActionResult> Dashboard()
    {
        var r = await _api.Get<List<EventDto>>(Routes.MyEvents);
        if (!r.Ok) TempData["Error"] = r.Error;
        return View(r.Data ?? new List<EventDto>());
    }

    // ---------- Events ----------
    public async Task<IActionResult> Events()
    {
        var r = await _api.Get<List<EventDto>>(Routes.MyEvents);
        if (!r.Ok) TempData["Error"] = r.Error;
        return View((r.Data ?? new()).OrderByDescending(e => e.Date).ToList());
    }

    [HttpGet] public IActionResult Create() => View("EventForm", new EventFormVm());

    [HttpPost]
    public async Task<IActionResult> Create(EventFormVm m)
    {
        if (!ValidImage(m)) return View("EventForm", m);
        if (!ModelState.IsValid) return View("EventForm", m);

        var r = await _api.Post<EventDto>(Routes.Events, Payload(m));
        if (!r.Ok || r.Data == null)
        {
            ModelState.AddModelError("", r.Ok ? "Could not create the event." : r.Error);
            return View("EventForm", m);
        }
        if (m.Banner != null)
        {
            var up = await _api.Upload<object>(Routes.Banner(r.Data.Id), m.Banner);
            if (!up.Ok) TempData["Error"] = "Event created, but the banner upload failed: " + up.Error;
        }
        if (TempData["Error"] == null) TempData["Success"] = "Event created.";
        return RedirectToAction(nameof(Events));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var r = await _api.Get<EventDto>(Routes.Event(id));
        if (!r.Ok || r.Data == null) { TempData["Error"] = r.Ok ? "Event not found." : r.Error; return RedirectToAction(nameof(Events)); }
        var e = r.Data;
        return View("EventForm", new EventFormVm
        {
            Id = e.Id, Name = e.Name, Description = e.Description, Date = e.Date,
            Location = e.Location, DistanceKm = e.DistanceKm, EventType = e.EventType, BannerUrl = e.BannerUrl
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, EventFormVm m)
    {
        m.Id = id;
        if (!ValidImage(m)) return View("EventForm", m);
        if (!ModelState.IsValid) return View("EventForm", m);

        var r = await _api.Put<object>(Routes.Event(id), Payload(m));
        if (!r.Ok)
        {
            ModelState.AddModelError("", r.Error);
            return View("EventForm", m);
        }
        if (m.Banner != null)
        {
            var up = await _api.Upload<object>(Routes.Banner(id), m.Banner);
            if (!up.Ok) { TempData["Error"] = "Event saved, but the banner upload failed: " + up.Error; return RedirectToAction(nameof(Events)); }
        }
        TempData["Success"] = "Event updated.";
        return RedirectToAction(nameof(Events));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var r = await _api.Delete<object>(Routes.Event(id));
        if (r.Ok) TempData["Success"] = "Event deleted."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Events));
    }

    // ---------- Categories ----------
    public async Task<IActionResult> Categories(int id)
    {
        var ev = await _api.Get<EventDto>(Routes.Event(id));
        if (!ev.Ok || ev.Data == null) { TempData["Error"] = ev.Error; return RedirectToAction(nameof(Events)); }
        var cats = await _api.Get<List<CategoryDto>>(Routes.Categories(id));
        if (!cats.Ok) TempData["Error"] = cats.Error;
        ViewBag.Event = ev.Data;
        return View(cats.Data ?? new List<CategoryDto>());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(int id, string name, string type)
    {
        if (string.IsNullOrWhiteSpace(name)) { TempData["Error"] = "Please enter a category name."; return RedirectToAction(nameof(Categories), new { id }); }
        var r = await _api.Post<object>(Routes.Categories(id), new { name = name.Trim(), type = type == "Distance" ? "Distance" : "Age" });
        if (r.Ok) TempData["Success"] = "Category added."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Categories), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteCategory(int id, int eventId)
    {
        var r = await _api.Delete<object>(Routes.Category(id));
        if (r.Ok) TempData["Success"] = "Category removed."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Categories), new { id = eventId });
    }

    // ---------- Enrolments ----------
    public async Task<IActionResult> Enrolments(int id)
    {
        var ev = await _api.Get<EventDto>(Routes.Event(id));
        if (!ev.Ok || ev.Data == null) { TempData["Error"] = ev.Error; return RedirectToAction(nameof(Events)); }
        var r = await _api.Get<List<EnrolmentDto>>(Routes.EventEnrolments(id));
        if (!r.Ok) TempData["Error"] = r.Error;
        ViewBag.Event = ev.Data;
        return View(r.Data ?? new List<EnrolmentDto>());
    }

    // ---------- Results ----------
    [HttpGet]
    public async Task<IActionResult> Results(int id)
    {
        var ev = await _api.Get<EventDto>(Routes.Event(id));
        if (!ev.Ok || ev.Data == null) { TempData["Error"] = ev.Error; return RedirectToAction(nameof(Events)); }
        var r = await _api.Get<List<EnrolmentDto>>(Routes.EventEnrolments(id));
        if (!r.Ok) TempData["Error"] = r.Error;
        ViewBag.Event = ev.Data;
        var enrolled = (r.Data ?? new()).Where(e => !string.Equals(e.Status, "Cancelled", StringComparison.OrdinalIgnoreCase)).ToList();
        return View(enrolled);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Results(int id, List<ResultEntryDto> entries)
    {
        var filled = (entries ?? new()).Where(e => !string.IsNullOrWhiteSpace(e.FinishTime) || e.Position > 0).ToList();
        if (filled.Count == 0) { TempData["Error"] = "Enter at least one result."; return RedirectToAction(nameof(Results), new { id }); }

        foreach (var e in filled)
        {
            if (!TimeSpan.TryParse(e.FinishTime, out var ts) || ts <= TimeSpan.Zero || e.Position < 1)
            {
                TempData["Error"] = "Each result needs a finish time (e.g. 01:45:30) and a position of 1 or higher.";
                return RedirectToAction(nameof(Results), new { id });
            }
            e.FinishTime = ts.ToString(@"hh\:mm\:ss");
        }
        if (filled.Select(e => e.Position).Distinct().Count() != filled.Count)
        {
            TempData["Error"] = "Two participants can't share the same finishing position.";
            return RedirectToAction(nameof(Results), new { id });
        }

        var r = await _api.Post<object>(Routes.Results(id), filled);
        if (r.Ok) TempData["Success"] = "Results published."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Results), new { id });
    }

    // ---------- helpers ----------
    private static object Payload(EventFormVm m) => new
    {
        name = m.Name.Trim(), description = m.Description.Trim(), date = m.Date,
        location = m.Location.Trim(), distanceKm = m.DistanceKm, eventType = m.EventType
    };

    private bool ValidImage(EventFormVm m)
    {
        if (m.Banner == null) return true;
        if (!AllowedImages.Contains(m.Banner.ContentType)) ModelState.AddModelError(nameof(m.Banner), "Banner must be a JPG, PNG or WebP image.");
        else if (m.Banner.Length > MaxImageBytes) ModelState.AddModelError(nameof(m.Banner), "Banner must be smaller than 5 MB.");
        return ModelState.IsValid;
    }
}
