using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Filters;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Controllers;

[SessionAuth]
public class HomeController : Controller
{
    private readonly ApiService _api;
    public HomeController(ApiService api) => _api = api;

    public async Task<IActionResult> Index(string? search, string? type, double? maxDistance)
    {
        var r = await _api.Get<List<EventDto>>(Routes.Events);
        if (!r.Ok) TempData["Error"] = r.Error;

        var events = (r.Data ?? new()).Where(e => e.Date >= DateTime.Today);
        if (!string.IsNullOrWhiteSpace(search))
            events = events.Where(e => e.Name.Contains(search, StringComparison.OrdinalIgnoreCase)
                                    || e.Location.Contains(search, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(type))
            events = events.Where(e => string.Equals(e.EventType, type, StringComparison.OrdinalIgnoreCase));
        if (maxDistance.HasValue)
            events = events.Where(e => e.DistanceKm <= maxDistance.Value);

        var all = r.Data ?? new();
        ViewBag.Types = all.Select(e => e.EventType).Where(t => !string.IsNullOrEmpty(t)).Distinct().OrderBy(t => t).ToList();
        ViewBag.Search = search; ViewBag.Type = type; ViewBag.MaxDistance = maxDistance;
        return View(events.OrderBy(e => e.Date).ToList());
    }

    public async Task<IActionResult> Details(int id)
    {
        var ev = await _api.Get<EventDto>(Routes.Event(id));
        if (!ev.Ok || ev.Data == null)
        {
            TempData["Error"] = ev.Ok ? "Event not found." : ev.Error;
            return RedirectToAction(nameof(Index));
        }
        var cats = await _api.Get<List<CategoryDto>>(Routes.Categories(id));
        ViewBag.Categories = cats.Data ?? new List<CategoryDto>();
        return View(ev.Data);
    }

    public IActionResult Error() => View();
}
